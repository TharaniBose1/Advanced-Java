package com.cg.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/controller")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public Login() {
        super();
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		RequestDispatcher dispatcher=null;
		if(userName.equalsIgnoreCase("user") && password.equalsIgnoreCase("user")) {
			dispatcher=request.getRequestDispatcher("loginSuccess.jsp");
			 dispatcher.forward(request, response);	}
		else
			request.getRequestDispatcher("loginFailure.jsp").forward(request, response);
	}

}
