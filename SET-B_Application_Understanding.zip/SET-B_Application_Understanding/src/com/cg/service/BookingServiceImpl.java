package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.BookingDAO;
import com.cg.dto.HotelDetails;
@Service
public class BookingServiceImpl implements BookingService{
@Autowired
BookingDAO bookingDAO=null;
	public BookingDAO getBookingDAO() {
	return bookingDAO;
}

public void setBookingDAO(BookingDAO bookingDAO) {
	this.bookingDAO = bookingDAO;
}

	@Override
	public ArrayList<HotelDetails> getAllDetails() {
		
		return bookingDAO.getAllDetails();
	}

}
