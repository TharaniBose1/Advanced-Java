package com.cg.dao;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.dto.HotelDetails;
@Repository
@Transactional
public class BookingDAOImpl implements BookingDAO{
	@PersistenceContext
	EntityManager entityManager=null;
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	@Override
	public ArrayList<HotelDetails> getAllDetails() {
		String query="Select ref From HotelDetails ref";
		ArrayList<HotelDetails> updatedList=(ArrayList<HotelDetails>) entityManager.createQuery(query, HotelDetails.class).getResultList();
		return updatedList;
	}

}
