package com.cg.dao;
import java.util.ArrayList;
import com.cg.dto.HotelDetails;
public interface BookingDAO {
public ArrayList<HotelDetails>getAllDetails();
}
