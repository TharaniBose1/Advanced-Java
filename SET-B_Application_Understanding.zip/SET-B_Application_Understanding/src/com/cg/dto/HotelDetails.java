package com.cg.dto;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class HotelDetails {
	@Id
private int ID;
private String name;
private int rating;
private int rate;
private int availableRooms;
public HotelDetails() {}
public int getID() {
	return ID;
}
public void setID(int iD) {
	ID = iD;
}

public String getName() {
	return name;
}
public void setName(String name) {
	name = name;
}
public int getRating() {
	return rating;
}
public void setRating(int rating) {
	this.rating = rating;
}
public int getRate() {
	return rate;
}
public void setRate(int rate) {
	this.rate = rate;
}
public int getAvailableRooms() {
	return availableRooms;
}
public void setAvailableRooms(int availableRooms) {
	this.availableRooms = availableRooms;
}

}
