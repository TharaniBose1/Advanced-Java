/*for (var a = 1; a <= 10; a++) {
	document.write("Hello World!<br>");
	console.log("Printed");
}*/
function callForWork(){
	alert("Hey You have pressed me!!");
	document.write("Hello World!");
}
function addNumbers(){
	var n1=parseInt(document.add.number1.value);
	var n2=parseInt(document.add.number2.value);
	var n3=n1+n2;
	document.add.answer.value=n3;
}