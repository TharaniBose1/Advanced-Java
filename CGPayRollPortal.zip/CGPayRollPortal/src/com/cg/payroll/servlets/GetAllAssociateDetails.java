package com.cg.payroll.servlets;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
@WebServlet("/controller4")
public class GetAllAssociateDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PayrollServices payrollServices=new PayrollServicesImpl();
    public GetAllAssociateDetails() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher=null;
		List<Associate> associatesList= payrollServices.getAllAssociatesDetails();
			request.setAttribute("associate", associatesList);
		dispatcher=request.getRequestDispatcher("associateAllDetails.jsp");
		dispatcher.forward(request, response);	
	}

}
