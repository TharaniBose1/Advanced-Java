package com.cg.payroll.daoservices;
import java.util.List;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
public interface AssociateDAO {
Associate save(Associate associate);
boolean update( Associate associate);
boolean delete(int associate) throws AssociateDetailsNotFoundException;
Associate findOne(int associateId) throws AssociateDetailsNotFoundException;
List<Associate>findAll();
}
